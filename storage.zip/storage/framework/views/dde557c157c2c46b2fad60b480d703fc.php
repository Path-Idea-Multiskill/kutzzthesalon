
<section id="contact" class="bg-slate-950 px-4 py-16 text-white sm:px-6 lg:px-8 lg:py-20">
    <div class="mx-auto max-w-7xl">

        <div class="text-center">
            <p class="text-xs font-bold uppercase tracking-[0.25em] text-rose-400">
                Our Locations
            </p>

            <h2 class="mt-3 font-heading text-3xl font-bold sm:text-4xl">
                Visit KUTZ Salon
            </h2>

            <p class="mx-auto mt-4 max-w-2xl text-sm leading-7 text-slate-400">
                Discover our salon locations and contact your preferred branch.
            </p>
        </div>

        <div class="mt-10 grid grid-cols-1 gap-5 md:grid-cols-2 lg:grid-cols-3">

            <?php $__empty_1 = true; $__currentLoopData = $branches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $branch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <?php
                    $branchName = $branch->name ?? $branch->branch_name ?? 'KUTZ Salon';
                    $branchPhone = $branch->phone ?? $branch->phone_number ?? null;
                ?>

                <article class="rounded-2xl border border-white/10 bg-white/5 p-6 transition hover:border-rose-400/50 hover:bg-white/10">

                    <span class="inline-flex rounded-full bg-brand/20 px-3 py-1 text-xs font-bold text-rose-300">
                        KUTZ Branch
                    </span>

                    <h3 class="mt-5 font-heading text-xl font-bold">
                        <?php echo e($branchName); ?>

                    </h3>

                    <p class="mt-3 text-sm leading-7 text-slate-300">
                        <?php echo e($branch->address ?? ''); ?>

                        <?php if($branch->city): ?>
                            <br><?php echo e($branch->city); ?>

                        <?php endif; ?>
                        <?php if($branch->state): ?>
                            , <?php echo e($branch->state); ?>

                        <?php endif; ?>
                        <?php if($branch->pin_code ?? $branch->pincode ?? null): ?>
                            - <?php echo e($branch->pin_code ?? $branch->pincode); ?>

                        <?php endif; ?>
                    </p>

                    <?php if($branchPhone): ?>
                        <a href="tel:<?php echo e(preg_replace('/[^0-9+]/', '', $branchPhone)); ?>"
                           class="mt-5 inline-flex text-sm font-semibold text-rose-300 transition hover:text-white">
                            Call: <?php echo e($branchPhone); ?>

                        </a>
                    <?php endif; ?>

                    <?php if($branch->opening_time && $branch->closing_time): ?>
                        <p class="mt-3 text-xs text-slate-400">
                            Timings: <?php echo e(substr($branch->opening_time, 0, 5)); ?>

                            –
                            <?php echo e(substr($branch->closing_time, 0, 5)); ?>

                        </p>
                    <?php endif; ?>
                </article>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <p class="col-span-full rounded-2xl border border-white/10 bg-white/5 p-10 text-center text-sm text-slate-400">
                    Branch information will be available soon.
                </p>
            <?php endif; ?>

        </div>
    </div>
</section>
<?php /**PATH C:\web\kutz-salon\resources\views/frontend/home/sections/branches.blade.php ENDPATH**/ ?>