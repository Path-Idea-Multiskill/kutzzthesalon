
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">

    <meta name="viewport"
          content="width=device-width, initial-scale=1">

    <title><?php echo $__env->yieldContent('title', 'Kutz The Salon'); ?></title>

    <meta name="description"
          content="<?php echo $__env->yieldContent('meta_description', 'Kutz The Salon - Premium salon services'); ?>">

    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Poppins:wght@400;500;600;700;800&display=swap"
          rel="stylesheet">

    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>

    <?php if (isset($component)) { $__componentOriginal3f5aa9f12d398d70276ec1c19d738f38 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3f5aa9f12d398d70276ec1c19d738f38 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.global-theme','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('global-theme'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3f5aa9f12d398d70276ec1c19d738f38)): ?>
<?php $attributes = $__attributesOriginal3f5aa9f12d398d70276ec1c19d738f38; ?>
<?php unset($__attributesOriginal3f5aa9f12d398d70276ec1c19d738f38); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3f5aa9f12d398d70276ec1c19d738f38)): ?>
<?php $component = $__componentOriginal3f5aa9f12d398d70276ec1c19d738f38; ?>
<?php unset($__componentOriginal3f5aa9f12d398d70276ec1c19d738f38); ?>
<?php endif; ?>
</head>

<body class="min-w-0 bg-white font-sans text-slate-900">

    <div class="flex min-h-screen w-full min-w-0 flex-col">

        <?php echo $__env->make('frontend.components.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        <main id="main-content" class="w-full min-w-0 flex-1">
            <?php echo $__env->yieldContent('content'); ?>
        </main>

        <?php echo $__env->make('frontend.components.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    </div>

</body>
</html>
<?php /**PATH C:\web\kutz-salon\resources\views/frontend/layouts/app.blade.php ENDPATH**/ ?>