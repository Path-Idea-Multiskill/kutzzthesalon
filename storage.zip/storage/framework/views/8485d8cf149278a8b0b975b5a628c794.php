

<?php $__env->startSection('title', 'Our Services | KUTZ Salon'); ?>

<?php $__env->startSection('meta_description', 'Explore hair, beauty, makeup and salon services at KUTZ Salon.'); ?>

<?php $__env->startSection('content'); ?>

    

    
    <!-- <section class="bg-brand-light px-4 py-14 sm:px-6 lg:px-8 lg:py-20">
                <div class="mx-auto max-w-7xl text-center">

                    <nav aria-label="Breadcrumb" class="mb-5 text-xs text-slate-500">
                        <a href="<?php echo e(route('home')); ?>" class="hover:text-brand">Home</a>
                        <span class="mx-2">›</span>
                        <span class="font-semibold text-brand">Services</span>
                    </nav>

                    <p class="text-xs font-bold uppercase tracking-[0.2em] text-brand">
                        Our Expertise
                    </p>

                    <h1 class="mt-3 font-heading text-4xl font-bold text-slate-950 sm:text-5xl">
                        Explore Our <span class="text-brand">Services</span>
                    </h1>

                    <p class="mx-auto mt-5 max-w-2xl text-sm leading-7 text-slate-600 sm:text-base">
                        Discover professional salon treatments, beauty services and
                        personalized styling experiences at KUTZ Salon.
                    </p>

                </div>
            </section> -->


    

    <section id="services-hero" class="relative isolate w-full overflow-hidden bg-[#FFF2F4]"
        aria-labelledby="services-hero-heading">

        
        <!-- <div class="absolute inset-0 -z-20">

                <img src="<?php echo e(asset('assets/images/services/ser1.png')); ?>"
                    alt="KUTZ Salon professional hair, beauty and styling services" fetchpriority="high" decoding="async"
                    class="block h-full w-full object-cover object-center">

            </div> -->


        
        <div class="absolute inset-0 -z-20">

            <picture class="block h-full w-full">

                
                <source media="(max-width: 767px)" srcset="<?php echo e(asset('assets/images/services/ser2.png')); ?>">

                
                <img src="<?php echo e(asset('assets/images/services/ser1.png')); ?>"
                    alt="KUTZ Salon professional hair, beauty and styling services" fetchpriority="high" decoding="async"
                    class="block h-full w-full object-cover object-center">

            </picture>

        </div>



        
        <div class="pointer-events-none absolute inset-0 -z-10
                       hidden bg-gradient-to-r
                       from-[#FFF2F4]/90
                       via-[#FFF2F4]/55
                       to-transparent
                       md:block" aria-hidden="true"></div>


        
        <div class="pointer-events-none absolute inset-0 -z-10
                       bg-gradient-to-t
                       from-[#FFF2F4]/95
                       via-[#FFF2F4]/50
                       to-transparent
                       md:hidden" aria-hidden="true"></div>


        
        <div class="relative mx-auto flex
                       min-h-[560px] w-full max-w-7xl
                       items-end px-5 pb-12 pt-12

                       min-[375px]:min-h-[610px]
                       min-[375px]:pb-14

                       sm:min-h-[680px]
                       sm:px-8 sm:pb-16

                       md:min-h-[430px]
                       md:items-center
                       md:px-8 md:py-16

                       lg:min-h-[540px]
                       lg:px-10 lg:py-20

                       xl:min-h-[620px]">

            
            <div class="relative z-10 w-full
                           max-w-[580px]
                           text-center md:text-left">

                
                <nav aria-label="Breadcrumb" class="mb-5 flex flex-wrap
                               items-center justify-center
                               gap-2 text-xs text-slate-600
                               md:justify-start">

                    <a href="<?php echo e(route('home')); ?>" class="transition hover:text-brand">
                        Home
                    </a>

                    <span aria-hidden="true">›</span>

                    <span class="font-semibold text-brand">
                        Services
                    </span>

                </nav>


                
                <div class="mb-4 flex items-center
                               justify-center gap-3
                               md:justify-start">

                    <span class="h-px w-7 bg-brand"></span>

                    <p class="text-[10px] font-bold
                                   uppercase tracking-[0.24em]
                                   text-brand sm:text-xs">
                        OUR EXPERTISE
                    </p>

                    <span class="h-px w-7 bg-brand"></span>

                </div>


                
                <h1 id="services-hero-heading" class="font-heading
                               text-[35px] font-bold
                               leading-[1.15]
                               tracking-tight text-[#171717]

                               min-[375px]:text-[41px]
                               sm:text-[50px]
                               md:text-[45px]
                               lg:text-[60px]
                               xl:text-[68px]">
                    Explore Our

                    <span class="mt-1 block font-serif
                                   text-[43px] font-normal
                                   italic leading-[1.12]
                                   text-brand

                                   min-[375px]:text-[49px]
                                   sm:text-[60px]
                                   md:text-[55px]
                                   lg:text-[73px]
                                   xl:text-[80px]">
                        Services
                    </span>

                </h1>


                
                <p class="mx-auto mt-5 max-w-[470px]
                               text-[13px] leading-7
                               text-slate-700

                               sm:mt-6 sm:text-base
                               sm:leading-8

                               md:mx-0">
                    Discover professional salon treatments,
                    beauty services and personalized styling
                    experiences at KUTZ Salon.
                </p>

                

            </div>

        </div>

    </section>


    
    <section class="px-4 py-14 sm:px-6 lg:px-8 lg:py-20">
        <div class="mx-auto max-w-7xl">

            <div class="grid grid-cols-2 gap-3 sm:gap-5 md:grid-cols-3 lg:grid-cols-4">

                <?php $__empty_1 = true; $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                    <a href="<?php echo e(route('services.show', $service->slug)); ?>"
                        class="group flex min-w-0 flex-col overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm transition hover:-translate-y-1 hover:border-rose-200 hover:shadow-xl">

                        
                        <div class="aspect-[4/5] overflow-hidden bg-brand-light">

                            <?php if($service->image): ?>
                                <img src="<?php echo e(asset('storage/' . ltrim($service->image, '/'))); ?>" alt="<?php echo e($service->name); ?>"
                                    loading="lazy" class="h-full w-full object-cover transition duration-500 group-hover:scale-105">
                            <?php else: ?>
                                <div class="flex h-full items-center justify-center font-bold text-brand">
                                    KUTZ SALON
                                </div>
                            <?php endif; ?>

                        </div>

                        
                        <div class="flex flex-1 flex-col p-4">

                            
                            <p class="text-xs font-semibold text-brand">
                                <?php echo e($service->category?->name ?? 'Salon Service'); ?>

                            </p>

                            
                            <h2
                                class="mt-2 line-clamp-2 font-heading text-base font-bold text-slate-900 group-hover:text-brand">
                                <?php echo e($service->name); ?>

                            </h2>

                            
                            <p class="mt-3 line-clamp-2 text-xs leading-6 text-slate-500">
                                <?php echo e($service->short_description); ?>

                            </p>

                            
                            <div class="mt-auto flex flex-wrap items-center justify-between gap-2 pt-5">

                                
                                <?php if($service->duration_minutes): ?>
                                    <span class="text-xs text-slate-500">
                                        <?php echo e($service->duration_minutes); ?> min
                                    </span>
                                <?php endif; ?>

                            </div>

                            
                            
                            <div class="mt-4 border-t border-slate-100 pt-4">

                                <span class="flex min-h-10 w-full items-center
                                       justify-center gap-2
                                       rounded-xl bg-brand
                                       px-2 py-2.5
                                       text-center text-[10px] font-bold
                                       text-white shadow-sm
                                       transition-all duration-300
                                       group-hover:bg-brand-dark
                                       group-hover:shadow-md
                                       sm:min-h-11 sm:px-4
                                       sm:text-xs">
                                    View Service Details

                                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24"
                                        fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"
                                        stroke-linejoin="round"
                                        class="shrink-0 transition-transform duration-300 group-hover:translate-x-1"
                                        aria-hidden="true">
                                        <path d="M5 12h14" />
                                        <path d="m12 5 7 7-7 7" />
                                    </svg>
                                </span>

                            </div>

                        </div>

                    </a>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                    <p class="col-span-full rounded-2xl bg-slate-50 p-10 text-center text-slate-500">
                        No services are currently available.
                    </p>

                <?php endif; ?>

            </div>

            
            <div class="mt-10">
                <?php echo e($services->links()); ?>

            </div>

        </div>
    </section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\web\kutz-salon\resources\views/frontend/services/index.blade.php ENDPATH**/ ?>