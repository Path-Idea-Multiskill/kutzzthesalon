


<?php $__env->startSection('title', 'Academy Management | Kutz Salon'); ?>

<?php $__env->startSection('content'); ?>
<div class="mx-auto w-full max-w-7xl min-w-0 space-y-6 pb-8">

    <div class="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
            <p class="mb-1 text-xs font-bold uppercase tracking-widest text-brand">
                Training Programs
            </p>
            <h1 class="font-heading text-2xl font-bold sm:text-3xl">
                Academy Management
            </h1>
            <p class="mt-1 text-sm text-slate-500">
                Manage courses, fees, curriculum and visibility.
            </p>
        </div>

        <a href="<?php echo e(route('admin.academy-courses.create')); ?>"
           class="inline-flex min-h-11 items-center justify-center rounded-xl bg-brand px-5 text-sm font-semibold text-white hover:bg-brand-dark">
            + Add New Course
        </a>
    </div>

    <?php if(session('success')): ?>
        <div role="status" class="rounded-xl border border-green-200 bg-green-50 p-4 text-sm text-green-700">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <div class="grid grid-cols-1 gap-5 sm:grid-cols-2 xl:grid-cols-3">
        <?php $__empty_1 = true; $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <article class="min-w-0 overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm transition hover:shadow-lg">
                <div class="relative aspect-video bg-slate-100">
                    <?php if($course->image): ?>
                        <img src="<?php echo e(asset('storage/' . $course->image)); ?>"
                             alt="<?php echo e($course->title); ?>"
                             loading="lazy"
                             class="h-full w-full object-cover">
                    <?php else: ?>
                        <div class="flex h-full items-center justify-center text-sm text-slate-400">
                            No Cover Image
                        </div>
                    <?php endif; ?>

                    <span class="absolute left-3 top-3 rounded-full px-3 py-1 text-xs font-semibold
                        <?php echo e($course->is_active ? 'bg-green-50 text-green-700' : 'bg-white text-slate-600'); ?>">
                        <?php echo e($course->is_active ? 'Active' : 'Inactive'); ?>

                    </span>
                </div>

                <div class="space-y-4 p-5">
                    <div>
                        <h2 class="font-heading text-base font-bold text-slate-900">
                            <?php echo e($course->title); ?>

                        </h2>
                        <p class="mt-1 line-clamp-2 text-sm text-slate-500">
                            <?php echo e($course->short_description ?: $course->subtitle); ?>

                        </p>
                    </div>

                    <div class="flex flex-wrap items-center justify-between gap-2 border-y border-slate-100 py-3">
                        <span class="text-sm font-bold text-brand">
                            <?php echo e($course->fees !== null
                                ? '₹' . number_format((float) $course->fees, 2)
                                : 'Fees on request'); ?>

                        </span>

                        <span class="text-xs font-medium text-slate-500">
                            <?php echo e($course->duration ?: 'Duration not set'); ?>

                        </span>
                    </div>

                    <div class="flex gap-2">
                        <a href="<?php echo e(route('admin.academy-courses.edit', $course)); ?>"
                           class="inline-flex min-h-10 flex-1 items-center justify-center rounded-xl border border-slate-200 text-sm font-semibold text-slate-700 hover:bg-slate-50">
                            Edit Course
                        </a>

                        <form method="POST"
                              action="<?php echo e(route('admin.academy-courses.destroy', $course)); ?>"
                              onsubmit="return confirm('Permanently delete this course?')">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>

                            <button type="submit"
                                    class="min-h-10 rounded-xl border border-red-100 bg-red-50 px-4 text-sm font-semibold text-red-600">
                                Delete
                            </button>
                        </form>
                    </div>
                </div>
            </article>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="col-span-full rounded-2xl border border-dashed border-slate-300 bg-white px-5 py-16 text-center">
                <h3 class="font-heading text-lg font-bold">No courses added yet</h3>
                <p class="mt-2 text-sm text-slate-500">
                    Create your first academy training course.
                </p>
            </div>
        <?php endif; ?>
    </div>

    <?php echo e($courses->links()); ?>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\web\kutz-salon\resources\views/admin/academy/index.blade.php ENDPATH**/ ?>