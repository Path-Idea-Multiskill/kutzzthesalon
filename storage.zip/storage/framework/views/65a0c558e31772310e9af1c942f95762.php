
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, initial-scale=1">

    <title>Admin Login | Kutz Salon</title>

    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
    <?php if (isset($component)) { $__componentOriginal3f5aa9f12d398d70276ec1c19d738f38 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3f5aa9f12d398d70276ec1c19d738f38 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.global-theme','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('global-theme'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3f5aa9f12d398d70276ec1c19d738f38)): ?>
<?php $attributes = $__attributesOriginal3f5aa9f12d398d70276ec1c19d738f38; ?>
<?php unset($__attributesOriginal3f5aa9f12d398d70276ec1c19d738f38); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3f5aa9f12d398d70276ec1c19d738f38)): ?>
<?php $component = $__componentOriginal3f5aa9f12d398d70276ec1c19d738f38; ?>
<?php unset($__componentOriginal3f5aa9f12d398d70276ec1c19d738f38); ?>
<?php endif; ?>
</head>

<body class="flex min-h-screen items-center
             justify-center bg-brand-light
             px-4 py-8 font-sans">

    <div class="w-full max-w-md rounded-2xl
                border border-red-100 bg-white
                p-5 shadow-xl sm:p-8">

        <div class="mb-8 text-center">
            <h1 class="text-3xl font-bold text-brand">
                KUTZ
            </h1>

            <p class="mt-2 text-sm text-slate-500">
                Salon Admin Login
            </p>
        </div>

        <form method="POST"
              action="<?php echo e(route('admin.login.submit')); ?>"
              class="space-y-5">

            <?php echo csrf_field(); ?>

            <div>
                <label for="email"
                       class="mb-2 block text-sm font-medium">
                    Email Address
                </label>

                <input type="email"
                       id="email"
                       name="email"
                       value="<?php echo e(old('email')); ?>"
                       autocomplete="username"
                       required
                       class="w-full min-w-0 rounded-xl
                              border border-slate-300
                              px-4 py-3 outline-none
                              focus:border-brand">

                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="mt-1 text-sm text-red-600">
                        <?php echo e($message); ?>

                    </p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div>
                <label for="password"
                       class="mb-2 block text-sm font-medium">
                    Password
                </label>

                <input type="password"
                       id="password"
                       name="password"
                       autocomplete="current-password"
                       required
                       class="w-full min-w-0 rounded-xl
                              border border-slate-300
                              px-4 py-3 outline-none
                              focus:border-brand">
            </div>

            <button type="submit"
                    class="w-full rounded-xl bg-brand
                           px-5 py-3 font-semibold
                           text-white transition
                           hover:bg-brand-dark">
                Login to Dashboard
            </button>

        </form>

    </div>

</body>
</html>
<?php /**PATH C:\web\kutz-salon\resources\views/admin/auth/login.blade.php ENDPATH**/ ?>