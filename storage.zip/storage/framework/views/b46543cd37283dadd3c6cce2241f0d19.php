


<?php $__env->startSection('title', 'Website Settings | Kutz Salon'); ?>

<?php $__env->startSection('content'); ?>

<div class="mx-auto w-full max-w-6xl min-w-0 space-y-6">

    <div>
        <h2 class="font-heading text-xl font-bold text-slate-900 sm:text-2xl">
            Website Settings
        </h2>
        <p class="mt-1 text-sm text-slate-500">
            Manage salon information and global theme.
        </p>
    </div>

    <?php if(session('success')): ?>
        <div role="status"
             class="rounded-xl border border-green-200
                    bg-green-50 p-4 text-sm text-green-700">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <?php if($errors->any()): ?>
        <div role="alert"
             class="rounded-xl border border-red-200
                    bg-red-50 p-4 text-sm text-red-700">
            Please check the form fields.
        </div>
    <?php endif; ?>

    <form method="POST"
          action="<?php echo e(route('admin.settings.update')); ?>"
          class="space-y-6">

        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <!-- GENERAL INFORMATION -->
        <section class="rounded-2xl border border-slate-200
                        bg-white p-4 shadow-sm sm:p-6">

            <h3 class="mb-5 font-heading text-lg font-semibold">
                General Information
            </h3>

            <div class="grid grid-cols-1 gap-5 md:grid-cols-2">

                <div>
                    <label for="site_name"
                           class="mb-2 block text-sm font-medium">
                        Salon Name
                    </label>
                    <input id="site_name"
                           name="site_name"
                           required
                           maxlength="255"
                           value="<?php echo e(old('site_name', $settings->site_name)); ?>"
                           class="w-full min-w-0 rounded-xl
                                  border border-slate-300 px-4 py-3
                                  focus:border-brand focus:outline-none">
                    <?php $__errorArgs = ['site_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="mt-1 text-xs text-red-600"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div>
                    <label for="site_tagline"
                           class="mb-2 block text-sm font-medium">
                        Tagline
                    </label>
                    <input id="site_tagline"
                           name="site_tagline"
                           maxlength="255"
                           value="<?php echo e(old('site_tagline', $settings->site_tagline)); ?>"
                           class="w-full min-w-0 rounded-xl
                                  border border-slate-300 px-4 py-3
                                  focus:border-brand focus:outline-none">
                </div>

                <div>
                    <label for="email"
                           class="mb-2 block text-sm font-medium">
                        Email
                    </label>
                    <input type="email"
                           id="email"
                           name="email"
                           value="<?php echo e(old('email', $settings->email)); ?>"
                           class="w-full min-w-0 rounded-xl
                                  border border-slate-300 px-4 py-3
                                  focus:border-brand focus:outline-none">
                </div>

                <div>
                    <label for="phone"
                           class="mb-2 block text-sm font-medium">
                        Phone
                    </label>
                    <input type="tel"
                           id="phone"
                           name="phone"
                           value="<?php echo e(old('phone', $settings->phone)); ?>"
                           class="w-full min-w-0 rounded-xl
                                  border border-slate-300 px-4 py-3
                                  focus:border-brand focus:outline-none">
                </div>

                <div class="md:col-span-2">
                    <label for="address"
                           class="mb-2 block text-sm font-medium">
                        Address
                    </label>
                    <textarea id="address"
                              name="address"
                              rows="3"
                              class="w-full min-w-0 rounded-xl
                                     border border-slate-300 px-4 py-3
                                     focus:border-brand focus:outline-none"><?php echo e(old('address', $settings->address)); ?></textarea>
                </div>

            </div>
        </section>

        <!-- THEME COLORS -->
        <section class="rounded-2xl border border-slate-200
                        bg-white p-4 shadow-sm sm:p-6">

            <h3 class="mb-5 font-heading text-lg font-semibold">
                Theme Colors
            </h3>

            <div class="grid grid-cols-1 gap-5 sm:grid-cols-3">

                <?php $__currentLoopData = [
                    'primary_color' => 'Primary Color',
                    'secondary_color' => 'Secondary Color',
                    'light_color' => 'Light Color'
                ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <div>
                        <label for="<?php echo e($field); ?>"
                               class="mb-2 block text-sm font-medium">
                            <?php echo e($label); ?>

                        </label>

                        <input type="color"
                               id="<?php echo e($field); ?>"
                               name="<?php echo e($field); ?>"
                               value="<?php echo e(old($field, $settings->$field)); ?>"
                               class="h-12 w-full cursor-pointer
                                      rounded-xl border border-slate-300
                                      bg-white p-1">
                        <?php $__errorArgs = [$field];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="mt-1 text-xs text-red-600"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>
        </section>

        <!-- TYPOGRAPHY -->
        <section class="rounded-2xl border border-slate-200
                        bg-white p-4 shadow-sm sm:p-6">

            <h3 class="mb-5 font-heading text-lg font-semibold">
                Typography
            </h3>

            <div class="grid grid-cols-1 gap-5 md:grid-cols-2">

                <div>
                    <label for="heading_font"
                           class="mb-2 block text-sm font-medium">
                        Heading Font
                    </label>

                    <select id="heading_font"
                            name="heading_font"
                            class="w-full min-w-0 rounded-xl
                                   border border-slate-300 px-4 py-3">

                        <?php $__currentLoopData = ['Poppins', 'Inter']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $font): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($font); ?>"
                                <?php if(old('heading_font', $settings->heading_font) === $font): echo 'selected'; endif; ?>>
                                <?php echo e($font); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </select>
                </div>

                <div>
                    <label for="body_font"
                           class="mb-2 block text-sm font-medium">
                        Body Font
                    </label>

                    <select id="body_font"
                            name="body_font"
                            class="w-full min-w-0 rounded-xl
                                   border border-slate-300 px-4 py-3">

                        <?php $__currentLoopData = ['Inter', 'Poppins']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $font): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($font); ?>"
                                <?php if(old('body_font', $settings->body_font) === $font): echo 'selected'; endif; ?>>
                                <?php echo e($font); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </select>
                </div>

            </div>
        </section>

        <div class="flex justify-stretch sm:justify-end">
            <button type="submit"
                    class="min-h-12 w-full rounded-xl bg-brand
                           px-8 py-3 font-semibold text-white
                           transition hover:bg-brand-dark
                           sm:w-auto">
                Save Settings
            </button>
        </div>

    </form>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\web\kutz-salon\resources\views/admin/settings/index.blade.php ENDPATH**/ ?>