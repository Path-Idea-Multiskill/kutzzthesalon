

<?php $__env->startSection('title', 'Beauty Blog | KUTZ Salon'); ?>

<?php $__env->startSection('content'); ?>

    


    

    <section id="blog-hero" class="relative isolate w-full overflow-hidden bg-[#FFF2F4]"
        aria-labelledby="blog-hero-heading">

        
        <div class="absolute inset-0 -z-20">

            <picture class="block h-full w-full">

                
                <source media="(max-width: 767px)" srcset="<?php echo e(asset('assets/images/blog/b2.png')); ?>">

                
                <img src="<?php echo e(asset('assets/images/blog/b1.png')); ?>"
                    alt="KUTZ Salon beauty blog, hairstyling and makeup inspiration" fetchpriority="high" decoding="async"
                    class="block h-full w-full object-cover object-center">

            </picture>

        </div>


        
        <div class="pointer-events-none absolute inset-0 -z-10
                   hidden
                   bg-gradient-to-r
                   from-[#FFF2F4]/90
                   via-[#FFF2F4]/55
                   to-transparent
                   md:block" aria-hidden="true"></div>


        
        <div class="pointer-events-none absolute inset-0 -z-10
                   bg-gradient-to-t
                   from-[#FFF2F4]/95
                   via-[#FFF2F4]/50
                   to-transparent
                   md:hidden" aria-hidden="true"></div>


        
        <div class="relative mx-auto flex
                   min-h-[560px] w-full max-w-7xl
                   items-end
                   px-5 pb-12 pt-12

                   min-[375px]:min-h-[610px]
                   min-[375px]:pb-14

                   sm:min-h-[680px]
                   sm:px-8 sm:pb-16

                   md:min-h-[430px]
                   md:items-center
                   md:px-8 md:py-16

                   lg:min-h-[540px]
                   lg:px-10 lg:py-20

                   xl:min-h-[620px]">

            
            <div class="relative z-10
                       w-full max-w-[570px]
                       text-center md:text-left">

                
                <div class="mb-5 flex items-center
                           justify-center gap-3
                           md:justify-start">

                    <span class="h-px w-7 bg-brand"></span>

                    <p class="text-[10px] font-bold
                               uppercase tracking-[0.24em]
                               text-brand sm:text-xs">
                        OUR BEAUTY BLOG
                    </p>

                    <span class="h-px w-7 bg-brand"></span>

                </div>


                
                <h1 id="blog-hero-heading" class="font-heading
                           text-[34px] font-bold
                           leading-[1.15]
                           tracking-tight text-[#171717]

                           min-[375px]:text-[40px]
                           sm:text-[49px]
                           md:text-[45px]
                           lg:text-[59px]
                           xl:text-[66px]">
                    Beauty Insights

                    <span class="mt-1 block font-serif
                               text-[39px] font-normal
                               italic leading-[1.12]
                               text-brand

                               min-[375px]:text-[46px]
                               sm:text-[58px]
                               md:text-[54px]
                               lg:text-[69px]
                               xl:text-[76px]">
                        & Inspiration
                    </span>

                </h1>


                
                <p class="mx-auto mt-5 max-w-[450px]
                           text-[13px] leading-7
                           text-slate-700

                           sm:mt-6 sm:text-base
                           sm:leading-8

                           md:mx-0">
                    Discover beauty tips, haircare advice,
                    makeup trends and expert salon insights.
                </p>

                

            </div>

        </div>

    </section>



    

    <section id="latest-posts" class="scroll-mt-24 px-4 py-16 sm:px-6 lg:py-20">

        <div class="mx-auto max-w-7xl">

            
            <div class="flex flex-wrap justify-center gap-3">

                <a href="<?php echo e(route('blogs.index')); ?>"
                    class="rounded-full border px-5 py-2.5 text-sm font-semibold <?php echo e(!request('category') ? 'border-brand bg-brand text-white' : 'border-rose-200 bg-white text-slate-700'); ?>">
                    All Posts
                </a>

                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <a href="<?php echo e(route('blogs.index', ['category' => $category->slug])); ?>"
                        class="rounded-full border px-5 py-2.5 text-sm font-semibold transition <?php echo e(request('category') === $category->slug ? 'border-brand bg-brand text-white' : 'border-rose-200 bg-white text-slate-700 hover:border-brand hover:text-brand'); ?>">
                        <?php echo e($category->name); ?>

                    </a>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>


            
            <div class="mt-10 text-center">

                <p class="text-xs font-bold uppercase tracking-widest text-brand">
                    OUR LATEST POSTS
                </p>

                <h2 class="mt-3 font-heading text-3xl font-bold sm:text-4xl">
                    Beauty Insights & <span class="text-brand">Inspiration</span>
                </h2>

            </div>


            
            <div class="mt-10 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">

                <?php $__empty_1 = true; $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                    <article
                        class="group flex flex-col overflow-hidden rounded-2xl border border-rose-100 bg-white shadow-sm transition hover:-translate-y-1 hover:shadow-xl">

                        
                        <a href="<?php echo e(route('blogs.show', $blog->slug)); ?>"
                            class="relative block aspect-[16/10] overflow-hidden bg-brand-light">

                            <?php if($blog->featured_image): ?>

                                <img src="<?php echo e(asset('storage/' . $blog->featured_image)); ?>" alt="<?php echo e($blog->title); ?>" loading="lazy"
                                    class="h-full w-full object-cover transition duration-500 group-hover:scale-105">

                            <?php endif; ?>

                            
                            <span class="absolute left-4 top-4 rounded-lg bg-brand px-3 py-1 text-xs font-bold text-white">
                                <?php echo e($blog->category?->name ?? 'Beauty'); ?>

                            </span>

                        </a>


                        
                        <div class="flex flex-1 flex-col p-6">

                            
                            <p class="text-xs text-slate-500">

                                <?php echo e($blog->published_at?->format('d M Y')); ?>


                                <?php if($blog->author_name): ?>
                                    · <?php echo e($blog->author_name); ?>

                                <?php endif; ?>

                            </p>


                            
                            <h3 class="mt-3 line-clamp-2 min-h-[56px] font-heading text-lg font-bold leading-7 text-slate-950">

                                <a href="<?php echo e(route('blogs.show', $blog->slug)); ?>" class="hover:text-brand">
                                    <?php echo e($blog->title); ?>

                                </a>

                            </h3>


                            
                            <p class="mt-3 line-clamp-3 text-sm leading-6 text-slate-500">
                                <?php echo e($blog->excerpt); ?>

                            </p>


                            
                            <a href="<?php echo e(route('blogs.show', $blog->slug)); ?>"
                                class="mt-auto inline-flex w-fit items-center gap-2 pt-5 text-sm font-bold text-brand">
                                Read More →
                            </a>

                        </div>

                    </article>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                    <p class="col-span-full rounded-2xl bg-brand-light p-10 text-center text-slate-600">
                        New beauty articles coming soon.
                    </p>

                <?php endif; ?>

            </div>


            
            <div class="mt-10">
                <?php echo e($blogs->links()); ?>

            </div>

        </div>

    </section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\web\kutz-salon\resources\views/frontend/blogs/index.blade.php ENDPATH**/ ?>