

<?php $__env->startSection('title', 'KUTZ Salon | Premium Beauty & Hair Services'); ?>

<?php $__env->startSection('meta_description', 'Explore professional hair styling, bridal makeup, skincare, salon services and academy courses at KUTZ Salon.'); ?>

<?php $__env->startSection('content'); ?>

    <?php echo $__env->make('frontend.home.sections.hero', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <?php echo $__env->make('frontend.home.sections.statistics', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <?php echo $__env->make('frontend.home.sections.services', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <?php echo $__env->make('frontend.home.sections.videos', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <?php echo $__env->make('frontend.home.sections.gallery', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <!-- <?php echo $__env->make('frontend.home.sections.instagram', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?> -->


    <?php echo $__env->make('frontend.home.sections.experience', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <?php echo $__env->make('frontend.home.sections.instagram-reels', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <?php echo $__env->make('frontend.home.sections.testimonials', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <?php echo $__env->make('frontend.home.sections.blogs', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <!-- <?php echo $__env->make('frontend.home.sections.academy', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?> -->

    <!-- <?php echo $__env->make('frontend.home.sections.branches', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?> -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\web\kutz-salon\resources\views/frontend/home/index.blade.php ENDPATH**/ ?>